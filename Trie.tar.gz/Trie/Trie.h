//
// Created by zack on 02/04/20.
//

#ifndef ALGORITHMS_TRIE_H
#define ALGORITHMS_TRIE_H

#include "TrieNode.h"
#include<iostream>
using namespace std;

class Trie {
    TrieNode * root;
    bool exists =true;
    void delete_String(string &s,TrieNode *,TrieNode * root,int);
    TrieNode * insert(char data,TrieNode * root);
    void deleteall(TrieNode * root);
    TrieNode *  initialiseSearch(TrieNode *,string &);
    void searchCompletely(TrieNode *, basic_string<char> );

public:
    Trie();
    void insert(string s);
    bool isEmpty();
    void SearchPrefix(string s);
    bool delete_String(string s);
    ~Trie();

};


#endif //ALGORITHMS_TRIE_H
