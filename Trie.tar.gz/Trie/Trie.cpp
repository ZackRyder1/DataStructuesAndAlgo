//
// Created by zack on 02/04/20.
//

#include "Trie.h"

Trie::Trie()
{
this->root = new TrieNode(' '); //Master node
}

void Trie::insert(string s) {
    TrieNode * temp = this->root;
    for(int i=0;i<s.length();i++)
        temp = insert(s[i],temp);
    int freq = temp->getFrequency();
    temp->setFrequency(++freq);
}

bool Trie::isEmpty() {
    return !this->root;
}

TrieNode *Trie::insert(char data, TrieNode *root) {
    TrieNode * f = root->addChild(data);
    return f;
}

Trie::~Trie() {
    deleteall(this->root);
}

void Trie::deleteall(TrieNode * root) {
    if(root->getChildren()->empty())
    {
        delete root;
        return;
    }
    list<TrieNode*>::iterator it;
    for(it = root->getChildren()->begin();it!= root->getChildren()->end();it++)
        deleteall(*it);
    delete root;

}

void Trie::SearchPrefix(string s) {
    TrieNode * temp = initialiseSearch(this->root,s);
    if(!temp)
    {
        cout << "No Such Word with the following prefix exist" << '\n';
        return;
    }
    cout<<"All the Words starting with "<<s<<" are:"<<'\n';
    searchCompletely(temp,s);


}

TrieNode * Trie::initialiseSearch(TrieNode * root,string & s) {
    TrieNode * temp = root;
    for(int i=0;i<s.length();i++) {
        if(temp)
            temp = temp->find(s[i]);
        else {
            return nullptr;
        }
    }
    return temp;
}

void Trie::searchCompletely(TrieNode * root, basic_string<char>  s) {
    if(root->isValid())
        cout<<s<<'\n';
    if(root->getChildren()->empty())
        return;

    list<TrieNode*>::iterator it;
    for(it = root->getChildren()->begin();it != root->getChildren()->end();it++)
        searchCompletely(*it,s + (*it)->getData());
}

bool Trie::delete_String(string s) {
    delete_String(s, nullptr,this->root,0);
    bool temp = this->exists;
    this->exists = true;
    return temp;
}

void Trie::delete_String(string &s,TrieNode* parent, TrieNode *root,int iterator) {

    if(!root) {
        parent->setFrequency(parent->getFrequency()-1);
        this->exists = false;
        return;
    }
    if(iterator == s.length()+1 || !(this->exists))
        return;

    delete_String(s,root,root->find(s[iterator]),iterator+1);
    if(root->getChildren()->empty() && root->getFrequency() == 0)
    {
        parent->getChildren()->remove(root);
        delete root;
    }
}




