//
// Created by zack on 02/04/20.
//

#ifndef ALGORITHMS_TRIENODE_H
#define ALGORITHMS_TRIENODE_H
#include <list>
using namespace std;


class TrieNode {


    char data;
    int frequency;
    list<TrieNode*> *children;

public:
    TrieNode();

    TrieNode(char data);

    char getData() const;

    int getFrequency() const;

    bool isValid();

    void setFrequency(int frequency);

    void setData(char data);

    list<TrieNode *> *getChildren() const;

    TrieNode* addChild(char data);

    TrieNode* find(char data);

    ~TrieNode();
};


#endif //ALGORITHMS_TRIENODE_H
