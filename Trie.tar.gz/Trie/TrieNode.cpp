//
// Created by zack on 02/04/20.
//
#include<iostream>
#include "TrieNode.h"
TrieNode::TrieNode()
{
    this->data = '0';
    this->children = nullptr;
    this->frequency = -1;
}

TrieNode::TrieNode(char data)
{
    this->data = data;
    this->children = new list<TrieNode*>();
    this->frequency = 0;
}

TrieNode::~TrieNode() {
    std::cout<<"Deleting the node having data "<<this->getData()<<'\n';
}

char TrieNode::getData() const {
    return data;
}

void TrieNode::setData(char data) {
    TrieNode::data = data;
}

list<TrieNode *> *TrieNode::getChildren() const {
    return children;
}

TrieNode * TrieNode::addChild(char data) {
    TrieNode * f;
    if(!(f = find(data))) {
        f = new TrieNode(data);
        this->children->push_front(f);
    }
    return f;
}

TrieNode* TrieNode::find(char data) {
    list<TrieNode*>::iterator it;
    for(it=this->children->begin();it!=this->children->end();it++)
    {
        if((*it)->getData() == data)
            return *it;
    }
    return nullptr;
}

int TrieNode::getFrequency() const {
    return frequency;
}

void TrieNode::setFrequency(int frequency) {
    TrieNode::frequency = frequency;
}

bool TrieNode::isValid() {
    return this->getFrequency()>0;
}


