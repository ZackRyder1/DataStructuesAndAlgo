import java.util.*;

public class PrimAlgo {
    public static void main(String[] args) {
        Graph g =new Graph();
        Vertex a = new Vertex('a');
        Vertex b = new Vertex('b');
        Vertex c = new Vertex('c');
        Vertex d = new Vertex('d');
        Vertex e = new Vertex('e');
        Vertex f = new Vertex('f');
        g.addVertex(a);
        g.addVertex(b);
        g.addVertex(c);
        g.addVertex(d);
        g.addVertex(e);
        g.addVertex(f);
        g.addEdge(a,b,10);
        g.addEdge(a,e,20);
        g.addEdge(b,e,11);
        g.addEdge(b,c,20);
        g.addEdge(e,f,22);
        g.addEdge(c,f,15);
        g.addEdge(c,d,50);
        g.addEdge(d,f,14);
//        g.print();
        Edge minVertex = getMinVertex(g);
        System.out.println(minVertex.getSrc()+":"+minVertex.getDest()+":"+minVertex.getWeight());
        Graph MST = prim_MST(g);
        MST.print();


    }

    public static Graph prim_MST(Graph g)
    {
        Edge minCost = getMinVertex(g);
        Graph MST = new Graph();
        MST.addVertex(g.getVertex(minCost.getSrc()));
        MST.addVertex(g.getVertex(minCost.getDest()));
        MST.addEdge(g.getVertex(minCost.getSrc()),g.getVertex(minCost.getDest()),minCost.getWeight());
        int near[] = new int[g.getVertices().size()];
        for(int i=0;i<near.length;i++)
        {
            Edge edge1 = g.getEdges().get(minCost.getSrc()).get(i);
            Edge edge2 = g.getEdges().get(minCost.getDest()).get(i);
            if(edge1 == null && edge2 == null)
                near[i] =Integer.MAX_VALUE;
            else if(edge1 == null || edge2 == null)
                near[i] = edge1 == null?edge2.getSrc():edge1.getSrc();
            else if(edge1.getWeight() < edge2.getWeight())
                near[i] = edge1.getSrc();
            else if(edge1.getWeight() > edge2.getWeight())
                near[i] = edge2.getSrc();
        }
        near[minCost.getSrc()] = near[minCost.getDest()] = 0;
        for(int i=0;i<near.length-2;i++)
        {
            int min_weight =Integer.MAX_VALUE;
            for(int j=0;j<near.length;j++)
            {
                if(near[j] != Integer.MAX_VALUE && near[j] !=0)
                {
                    Edge weight = g.getEdges().get(j).get(near[j]);
                    if(min_weight > weight.getWeight())
                    {
                        min_weight = weight.getWeight();
                        minCost = weight;
                    }
                }
            }
            MST.addVertex(g.getVertex(minCost.getSrc()));
            MST.addEdge(g.getVertex(minCost.getSrc()),g.getVertex(minCost.getDest()),minCost.getWeight());
            near[minCost.getSrc()] = 0;
            for(int k=0;k<near.length;k++)
            {
                if(near[k] !=0) {
                    Edge edge1 = g.getEdges().get(k).get(near[k]);
                    Edge edge2 = g.getEdges().get(k).get(minCost.getSrc());
                    if(edge1 == null && edge2 == null)
                        continue;
                    else if(edge2 == null)
                        continue;
                    else if(edge1 == null)
                        near[k] = minCost.getSrc();
                    else if (edge1.getWeight() > edge2.getWeight())
                        near[k] = minCost.getSrc();
                }
            }
        }
        return MST;
    }

    public static Edge getMinVertex(Graph g)
    {   Edge minCost = null;
        int minWeight=Integer.MAX_VALUE;
        for(int i=0;i<g.getEdges().size();i++)
        {
            for(Edge e:g.getEdges().get(i).values())
            {
                if(minWeight>e.getWeight())
                {
                    minWeight = e.getWeight();
                    minCost = e;
                }
            }

        }
        return minCost;
    }
}
