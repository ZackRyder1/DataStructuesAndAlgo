import javax.xml.stream.events.EndDocument;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Graph {
    private ArrayList<Vertex> vertices;
    private ArrayList<HashMap<Integer,Edge>> edges;
    private int size;


    public Graph()
    {
        this.vertices = new ArrayList<>();
        this.edges = new ArrayList<>();
    }


    public ArrayList<HashMap<Integer, Edge>> getEdges() {
        return edges;
    }

    public void addVertex(Vertex v)
    {
        this.vertices.add(v);
        v.setArray_index(this.vertices.size()-1);
        edges.add(new HashMap<>());
    }

    public Vertex getVertex(int array_index)
    {
        return this.vertices.get(array_index);
    }

    public ArrayList<Vertex> getVertices() {
        return vertices;
    }

    public void addEdge(Vertex src, Vertex dest, int weight)
    {
        Edge edge = new Edge(src.getArray_index(),dest.getArray_index(),weight);
        edges.get(src.getArray_index()).put(edge.getDest(),edge);
        edges.get(dest.getArray_index()).put(src.getArray_index(),new Edge(dest.getArray_index(),src.getArray_index(),weight));
    }



    public void print()
    {
        for(int i=0;i<edges.size();i++)
        {
            for(Edge e:edges.get(i).values())
            {
                System.out.println("The Vertex "+getVertex(e.getSrc())+" is connected to "+getVertex(e.getDest())+" with weight "+e.getWeight());
            }
        }
    }
}

class Vertex{
    private char node_name;
    private int array_index;

    public Vertex(char node_name)
    {
        this.node_name = node_name;
    }

    public char getNode_name() {
        return node_name;
    }

    public void setArray_index(int array_index) {
        this.array_index = array_index;
    }

    public int getArray_index() {
        return array_index;
    }

    @Override
    public String toString() {
        return Character.toString(this.node_name);
    }
}

class Edge implements Comparable<Edge>{
    private int src;
    private int dest;
    private int weight;

    public Edge(int src, int dest, int weight) {
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }

    public int getSrc() {
        return src;
    }

    public int getDest() {
        return dest;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public int compareTo(Edge o) {
        if(o.getWeight() == this.getWeight())
            return 0;
        else if(o.getWeight() > this.getWeight())
            return -1;
        else
            return 1;
    }
}



