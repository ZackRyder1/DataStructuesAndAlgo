//
// Created by zack on 28/03/20.
//

#include <iostream>
using namespace std;
#include "MinHeap.h"
#include <cmath>

MinHeap::MinHeap(int size): max_size(size)
{
    this->size = 0;
    this->heap = new HuffManNode[size];
}

MinHeap::MinHeap(HuffManNode * arr, int size, int max): max_size(max)
{
    this->size = size;
    this->heap = arr;
}

int MinHeap::getSize() {
    return this->size;
}

int MinHeap::getParent(int index)
{
    return ceil((float)index/2)-1;
}

int MinHeap::getLeftChild(int index)
{
    return index*2+1;
}

int MinHeap::getRightChild(int index)
{
    return index*2+2;
}

int MinHeap::getNonLeaves()
{
    return floor(this->size/2)-1;
}

void MinHeap::Min_Heapify(int index)
{
    int leftC_index = getLeftChild(index);
    int rightC_index = getRightChild(index);
    int smallest_index = index;
    HuffManNode  smallest = this->heap[index];

    if(leftC_index<this->size && smallest.getFrequency()>this->heap[leftC_index].getFrequency())
    {
        smallest = this->heap[leftC_index];
        smallest_index = leftC_index;
    }

    if(rightC_index<this->size && smallest.getFrequency()>this->heap[rightC_index].getFrequency())
    {
        smallest = this->heap[rightC_index];
        smallest_index = rightC_index;
    }

    if(smallest_index != index)
    {
        this->heap[smallest_index] = this->heap[index];
        this->heap[index] = smallest;
        Min_Heapify(smallest_index);
    }
}


void MinHeap::build_Heap()
{
    for(int i=getNonLeaves();i>=0;i--)
    {
        Min_Heapify(i);
    }
}

HuffManNode *MinHeap::extract_Min()
{
    HuffManNode  min = this->heap[0];
    this->heap[0] = this->heap[--this->size];
    this->heap[this->size] = min;
    Min_Heapify(0);
    return new HuffManNode(min);
}

void MinHeap::list()
{
    cout<<"MinHeap Contents"<<'\n'<<"----------------------------"<<'\n';
    for(int i=0;i<this->size;i++)
    {
        cout<<"Value at Node["<<i<<"] is "<<this->heap[i].getFrequency()<<'\n';
    }
}

void MinHeap::increase_Key(int index,HuffManNode newValue)
{
    this->heap[index] = newValue;
    int temp_index = index;
    while(temp_index>0 && this->heap[getParent(temp_index)].getFrequency()> this->heap[temp_index].getFrequency())
    {
        HuffManNode temp = this->heap[getParent(temp_index)];
        this->heap[getParent(temp_index)] = this->heap[temp_index];
        this->heap[temp_index] = temp;
        temp_index = getParent(temp_index);
    }
}

void MinHeap::insert_Key(HuffManNode Value)
{
    if(this->size == this->max_size)
    {
        cout<<"MinHeap OverFlow"<<'\n';
        return;
    }

    this->size++;
    increase_Key(this->size-1,Value);
}








