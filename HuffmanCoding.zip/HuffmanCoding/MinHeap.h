//
// Created by zack on 28/03/20.
//

#ifndef UNTITLED_MINHEAP_H
#define UNTITLED_MINHEAP_H
#include "HuffManNode.h"

class MinHeap {
    HuffManNode * heap;
    int size;
    const int max_size;
public:

    MinHeap(int);

    MinHeap(HuffManNode*, int, int);

    int getSize();

    int getParent(int);

    int getLeftChild(int);

    int getRightChild(int);

    int getNonLeaves();

    void Min_Heapify(int);

    void build_Heap();

    HuffManNode * extract_Min();

    void list();

    void increase_Key(int index, HuffManNode newValue);

    void insert_Key(HuffManNode Value);
};


#endif //UNTITLED_MINHEAP_H
