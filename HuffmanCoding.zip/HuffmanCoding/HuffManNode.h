//
// Created by zack on 28/03/20.
//

#ifndef UNTITLED_HUFFMANNODE_H
#define UNTITLED_HUFFMANNODE_H


class HuffManNode {


    int frequency;
        HuffManNode * left;
        HuffManNode * right;

public:
    HuffManNode();

    HuffManNode(int);

    HuffManNode(HuffManNode &man);

    int getFrequency() const;

    void setFrequency(int frequency);

    HuffManNode *getLeft() const;

    void setLeft(HuffManNode *left);

    HuffManNode *getRight() const;

    void setRight(HuffManNode *right);
};


#endif //UNTITLED_HUFFMANNODE_H
