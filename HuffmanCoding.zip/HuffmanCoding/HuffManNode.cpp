//
// Created by zack on 28/03/20.
//

#include "HuffManNode.h"
#include <iostream>

HuffManNode::HuffManNode() {
    this->right = nullptr;
    this->left = nullptr;
    this->frequency = 0;
}

HuffManNode::HuffManNode(HuffManNode & man) {
    *this = man;
}

HuffManNode::HuffManNode(int frequency) {
    this->frequency = frequency;
    this->left = nullptr;
    this->right = nullptr;
}

int HuffManNode::getFrequency() const {
    return frequency;
}

void HuffManNode::setFrequency(int frequency) {
    HuffManNode::frequency = frequency;
}

HuffManNode *HuffManNode::getLeft() const {
    return left;
}

void HuffManNode::setLeft(HuffManNode *left) {
    HuffManNode::left = left;
}

HuffManNode *HuffManNode::getRight() const {
    return right;
}

void HuffManNode::setRight(HuffManNode *right) {
    HuffManNode::right = right;
}


