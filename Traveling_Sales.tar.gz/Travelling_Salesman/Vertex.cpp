//
// Created by zack on 29/03/20.
//

#include "Vertex.h"

Vertex::Vertex()
{
    this->name = nullptr;
}

Vertex::~Vertex()
{
    delete this->adjList;
}

Vertex::Vertex(string name) {
    this->name = name;
    this->adjList = new map<string, Edge *>();
}




const string &Vertex::getName() const {
    return name;
}

map<string,Edge *> *Vertex::getEdges(){
    return this->adjList;
}

void Vertex::setName(const string &name) {
    Vertex::name = name;
}

void Vertex::addEdge(Vertex *v,int weight) {
    this->adjList->insert(pair<string,Edge*>(v->getName(),new Edge(v,weight)));
}

Edge * Vertex::getEdge(Vertex *dest) {
    Edge *e;
    try {
        e = this->adjList->at(dest->getName());
    }
    catch(...)
    {
        e = nullptr;
    }
    if(!e)
        return nullptr;

    return e;
}



