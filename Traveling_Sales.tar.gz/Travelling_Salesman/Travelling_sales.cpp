//
// Created by zack on 05/04/20.
//
#include "Graphs.h";
#include<iostream>
#include<unordered_set>
using namespace std;

int cost[10][10];
int num_Vertex;
map<int,Vertex*> mappings;

class Solution{
    list<char> * solution;
    int distance;

public:
    Solution() {
        this->solution = new list<char>();
        this->distance = 0;
    }

    list<char> *getSolution(){
        return solution;
    }


    int getDistance() const {
        return distance;
    }

    void setDistance(int distance) {
        Solution::distance = distance;
    }

};

bool compare(string s1,string s2)
{
    return s1[0]  == s2[0];
}

void initialise(Graphs * g,string source)
{
    map<string,Vertex*>::iterator it;
    int i = 1;
    bool flag =true;
    for(it=g->getVertices()->begin(); it!= g->getVertices()->end() ; it++,i++)
    {
        if(flag && compare(source,it->first)) {
            mappings.insert(pair<int, Vertex *>(0, it->second));
            flag =false;
            i--;
        }
        else
            mappings.insert(pair<int,Vertex*>(i,it->second));
    }

    num_Vertex = g->getVertices()->size();
    for(int i=0;i<num_Vertex;i++)
        for(int j=0;j<num_Vertex;j++)
        {
            Vertex * source =  mappings.at(i);
            Vertex * dest = mappings.at(j);
            Edge * edge = source->getEdge(dest);
            if(!edge)
                cost[i][j] = INT32_MAX;
            else
                cost[i][j] = edge->getWeight();
        }

}

int getMin(Solution * content[],int size)
{
    int min = INT32_MAX;
    int min_index;

    for(int i=0;i<size;i++)
    {
        if(min>content[i]->getDistance())
        {
            min = content[i]->getDistance();
            min_index = i;
        }
    }

    return min_index;
}

int * createNewSet(int * vertices,int size,int exclude)
{
    int * new_vertices = new int [size-1];
    int j = 0;
    for(int i=0;i<size;i++)
    {
        if(i == exclude)
            continue;
        new_vertices[j++] = vertices[i];
    }
    return new_vertices;
}

Solution * travellingSales(int source,int vertices[],int size)
{
    if(size == 0)
    {
        Solution * s = new Solution;
        s->setDistance(cost[source][0]);
        s->getSolution()->push_front(mappings.at(0)->getName()[0]);
        s->getSolution()->push_front(mappings.at(source)->getName()[0]);
        return s;
    }
    Solution * content[size];
    for(int i=0;i<size;i++)
    {
        int * new_vertices = createNewSet(vertices,size,i);
        content[i] = travellingSales(vertices[i],new_vertices,size-1);
        content[i]->setDistance(content[i]->getDistance() + cost[source][vertices[i]]);
        content[i]->getSolution()->push_front(mappings.at(source)->getName()[0]);
    }
    return content[getMin(content,size)];
}

void Print(Solution * s) {
    cout << "Travelling SalesMan should visit the cities in following order: " << '\n';
    list<char>::iterator it = s->getSolution()->begin();

    for(int i = 0;i<s->getSolution()->size()-1;i++,it++)
        cout << *it << "->";
    cout<<*it;
    cout<<'\n';
    cout<<"Minimum Distance travelled by Salesman is "<<s->getDistance()<<'\n';
}

int main()
{
    Graphs g;
    g.AddVertex("1");
    g.AddVertex("2");
    g.AddVertex("3");
    g.AddVertex("4");
    g.AddEdge("1","2",1);
    g.AddEdge("2","1",1);
    g.AddEdge("2","3",2);
    g.AddEdge("3","2",2);
    g.AddEdge("3","4",1);
    g.AddEdge("4","3",1);
    g.AddEdge("4","1",1);
    g.AddEdge("1","4",1);
    g.AddEdge("1","3",3);
    g.AddEdge("3","1",3);
    g.AddEdge("2","4",4);
    g.AddEdge("4","2",4);
    initialise(&g,"1");
    int vertices[3];
    vertices[0] = 1;
    vertices[1] = 2;
    vertices[2] = 3;
    Solution * s = travellingSales(0,vertices,3);
    Print(s);

    return 0;
}

