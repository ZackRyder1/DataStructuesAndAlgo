//
// Created by zack on 07/04/20.
//
#include<iostream>
#include "Graphs.h"
using namespace std;
int cost[4][4];
int warshall_table[5][4][4];
map<int,Vertex*> mappings;
int num_Vertex;

bool compare(string s1,string s2)
{
    return s1[0]  == s2[0];
}

void initialise(Graphs * g,string source)
{
    map<string,Vertex*>::iterator it;
    int i = 1;
    bool flag =true;
    for(it=g->getVertices()->begin(); it!= g->getVertices()->end() ; it++,i++)
    {
        if(flag && compare(source,it->first)) {
            mappings.insert(pair<int, Vertex *>(0, it->second));
            flag =false;
            i--;
        }
        else
            mappings.insert(pair<int,Vertex*>(i,it->second));
    }

    num_Vertex = g->getVertices()->size();
    for(int i=0;i<num_Vertex;i++)
        for(int j=0;j<num_Vertex;j++)
        {
            if(i==j)
            {
                cost[i][j] = 0;
                continue;
            }
            Vertex * source =  mappings.at(i);
            Vertex * dest = mappings.at(j);
            Edge * edge = source->getEdge(dest);
            if(!edge)
                cost[i][j] = INT32_MAX;
            else
                cost[i][j] = edge->getWeight();
        }

}

void FloydWarshall()
{
    for(int i=0;i<num_Vertex;i++)
        for(int j=0;j<num_Vertex;j++)
            warshall_table[0][i][j] = cost[i][j];

    for(int k=1;k<num_Vertex+1;k++)
    {
        for(int  i=0;i<num_Vertex;i++)
        {
            for(int j=0;j<num_Vertex;j++)
            {
                int current = warshall_table[k-1][i][j];
                int newDist = warshall_table[k-1][i][k-1] + warshall_table[k-1][k-1][j];
                warshall_table[k][i][j] = min(current,newDist);
            }
        }
    }
}

void printAllPairShortest()
{
    cout<<"The All Pair Shortest path Solution is : "<<'\n';
    for(int i=0;i<num_Vertex;i++) {
        for (int j = 0; j < num_Vertex; j++) {
            cout << warshall_table[num_Vertex][i][j] << '\t';
        }
        cout<<'\n';
    }
}

int main()
{
    Graphs g;
    g.AddVertex("1");
    g.AddVertex("2");
    g.AddVertex("3");
    g.AddVertex("4");
    g.AddEdge("1","2",11);
    g.AddEdge("2","1",11);
    g.AddEdge("2","3",7);
    g.AddEdge("3","2",7);
    g.AddEdge("3","4",2);
    g.AddEdge("4","3",2);
    g.AddEdge("4","1",6);
    g.AddEdge("1","4",6);
    g.AddEdge("1","3",1);
    g.AddEdge("3","1",1);
    g.AddEdge("2","4",3);
    g.AddEdge("4","2",3);
    initialise(&g,"1");
    FloydWarshall();
    printAllPairShortest();
    return 0;
}

