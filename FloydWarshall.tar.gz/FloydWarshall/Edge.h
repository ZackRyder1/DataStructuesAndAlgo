//
// Created by zack on 29/03/20.
//

#ifndef ALGORITHMS_EDGE_H
#define ALGORITHMS_EDGE_H


#include "Vertex.h"
#include <list>
using namespace std;
class Vertex;


class Edge {
    Vertex * destination;
    int weight;
public:
    Edge(Vertex* destination,int weight);

    Vertex *getDestination() const;

    int getWeight() const;

    list <Vertex*> * getList();


};


#endif //ALGORITHMS_EDGE_H
