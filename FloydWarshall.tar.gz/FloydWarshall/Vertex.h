//
// Created by zack on 29/03/20.
//

#ifndef ALGORITHMS_VERTEX_H
#define ALGORITHMS_VERTEX_H

#include <string>
#include<map>
#include "Edge.h"
using namespace std;
class Edge;


class Vertex {
    string name;
    map<string,Edge*> * adjList;

public:
    Vertex();

    Vertex(string name);

    void addEdge(Vertex * v,int weight);

    Edge * getEdge(Vertex * dest);

    ~Vertex();

    void setName(const string &name);

    const string &getName() const;

    map<string,Edge *> *getEdges();




};


#endif //ALGORITHMS_VERTEX_H
