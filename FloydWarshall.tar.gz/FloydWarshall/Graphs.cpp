//
// Created by zack on 29/03/20.
//

#include <iostream>
using namespace std;
#include "Graphs.h"
#include <iostream>
#include <queue>
using namespace std;

void Graphs::AddEdge(Vertex * source,Vertex * destination,int weight)
{
    source->addEdge(destination,weight);
}


void Graphs::Traversal_Init()
{
    this->traversal = new map<Vertex*,bool>();
    map<string,Vertex*>::iterator it;
    for(it=this->vertices->begin();it!=vertices->end();it++)
    {
        this->traversal->insert(pair<Vertex*,bool>(it->second,false));
    }
}

void Graphs::BFS_traversal(Vertex * v)
{

    Vertex * u = v;
    cout<<"Visited the node having name : " << u->getName()<<'\n';
    this->traversal->at(v) = true; //Setting current node as visited
    queue<Vertex*> * q = new queue<Vertex*>();

    while(true){
        map <string,Edge*> :: iterator it;
        map <string,Edge*> * list1 = u->getEdges();
        for(it=list1->begin(); it!=list1->end(); it++) //Accessing the Adjacent nodes
        {
            if(!(this->traversal->at(this->vertices->at(it->first))) )//is it visited Before???
            {
                q->push(this->vertices->at(it->first));
                cout<<"Visited the node having name : " << it->first<<'\n';
                this->traversal->at(this->vertices->at(it->first)) = true;
            }
        }
        if(q->empty())
            return;
        else
        {
            u = q->front();
            q->pop();
        }
    }
}

void Graphs::DFS_traversal(Vertex * v)
{
    Vertex * u = v;
    this->traversal->at(u) = true;
    cout<<"Visited the node having name : " << u->getName()<<'\n';
    map <string,Edge*> :: iterator it;
    map <string,Edge*> * list1 = u->getEdges();
    for(it=list1->begin(); it!=list1->end(); it++)
    {
        if(!(this->traversal->at(this->vertices->at(it->first))))
            DFS_traversal(this->vertices->at(it->first));
    }

}

Graphs::Graphs()
{
    this->vertices = new map<string,Vertex*>;
    this->traversal = nullptr;
}

void Graphs::AddVertex(string name)
{
    this->vertices->insert(pair<string,Vertex*>(name,new Vertex(name)));
}

void Graphs::AddEdge(string source, string destination, int weight) {
    AddEdge(this->vertices->at(source),this->vertices->at(destination),weight);
}

void Graphs::List()
{
    map<string,Vertex*> :: iterator i;
    for(i= this->vertices->begin(); i!=this->vertices->end(); i++)
    {
        cout<< "Visited Vertex :"<< i->first<<'\n';
        map<string,Edge*> * list1 = i->second->getEdges();
        map<string,Edge*> :: iterator t1;
        for(t1=list1->begin(); t1!= list1->end() ; t1++)
        {
            cout<<"The Vertex " << i->first << " is connected to " << (*t1).first<<" and has a weight of "<<(*t1).second->getWeight()<<'\n';
        }
        cout<<"--------------------------------------"<<'\n';
    }
}

void Graphs::BFS()
{
    Traversal_Init();
    map<string,Vertex*> :: iterator i;
    cout<<"BFS"<<'\n'<<"-----------------------------"<<'\n';
    for(i= this->vertices->begin(); i!=this->vertices->end(); i++)
    {
        if(!(this->traversal->at(i->second)))
            BFS_traversal(i->second);
    }
    cout<<"------------------------------"<<'\n';
}

void Graphs::DFS()
{
    Traversal_Init();
    map<string,Vertex*> :: iterator i;
    cout<<"DFS"<<'\n'<<"-----------------------------"<<'\n';
    for(i= this->vertices->begin(); i!=this->vertices->end(); i++)
    {
        if(!(this->traversal->at(i->second)))
            DFS_traversal(i->second);
    }
    cout<<"------------------------------"<<'\n';
}

Graphs::~Graphs()
{
    delete vertices;
    if(this->traversal != nullptr)
        delete traversal;
}

map<string, Vertex *> *Graphs::getVertices() const {
    return vertices;
}



