//
// Created by zack on 29/03/20.
//

#ifndef ALGORITHMS_GRAPHS_H
#define ALGORITHMS_GRAPHS_H

#include<map>
#include "Vertex.h"
#include <iostream>
#include <queue>
using namespace std;

class Graphs {
    map <string,Vertex*> * vertices;
    map<Vertex*,bool> * traversal;

    void AddEdge(Vertex *,Vertex *,int);
    void Traversal_Init();
    void BFS_traversal(Vertex * v);
    void DFS_traversal(Vertex * v);

public:
    Graphs();
    void AddVertex(string name);
    void AddEdge(string, string ,int);
    void List();
    void BFS();

    map<string, Vertex *> *getVertices() const;

    void DFS();
    ~Graphs();


};


#endif //ALGORITHMS_GRAPHS_H
