//
// Created by zack on 29/03/20.
//

#include "Edge.h"

Edge::Edge(Vertex* destination,int weight)
{
    this->destination = destination;
    this->weight = weight;
}


Vertex *Edge::getDestination() const {
    return destination;
}

int Edge::getWeight() const {
    return weight;
}
